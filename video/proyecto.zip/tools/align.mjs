#!/usr/bin/env node
// Datologo — alineación de subtítulos con el audio real.
// 1) Lee el guion aprobado (script.txt) y la transcripción de Whisper (transcript.json).
// 2) Alinea palabra por palabra el texto conocido con lo que Whisper escuchó.
// 3) Ajusta los límites a las pausas reales del audio (ffmpeg silencedetect).
// 4) Escribe los tiempos dentro de index.html y genera las pistas de efectos sonoros.
// Uso: node tools/align.mjs [--words archivo.json] [--dir carpeta]
// Si algo falla, NO toca index.html (se renderiza con los tiempos que ya tenga) y sale con código 0.
import { readFileSync, writeFileSync, existsSync } from 'node:fs';
import { execFileSync } from 'node:child_process';
import { join } from 'node:path';

const args = process.argv.slice(2);
const opt = (k, d) => { const i = args.indexOf(k); return i >= 0 ? args[i + 1] : d; };
const DIR = opt('--dir', '.');
const P = (f) => join(DIR, f);
const report = [];
const log = (s) => { report.push(s); console.log(s); };

function fail(msg) {
  log('AVISO: ' + msg);
  log('Se conservan los tiempos que ya trae index.html.');
  writeFileSync(P('sync-report.txt'), report.join('\n') + '\n');
  process.exit(0);
}

// ---------- guion ----------
const norm = (w) => w.toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '').replace(/[^a-z0-9ñ]/g, '');
if (!existsSync(P('script.txt'))) fail('No existe script.txt');
const scriptText = readFileSync(P('script.txt'), 'utf8').replace(/\[[^\]]*\]/g, ' ');
const scriptWords = scriptText.split(/\s+/).filter((w) => norm(w).length > 0);
log(`Guion: ${scriptWords.length} palabras`);

// ---------- palabras reconocidas ----------
function fromWhisperFull(j) {
  const out = [];
  for (const seg of j.transcription ?? []) {
    for (const tk of seg.tokens ?? []) {
      const text = tk.text ?? '';
      if (!text.trim() || text.trim().startsWith('[_') || text.includes('[BLANK')) continue;
      const from = (tk.offsets?.from ?? 0) / 1000, to = (tk.offsets?.to ?? 0) / 1000;
      const dtw = typeof tk.t_dtw === 'number' && tk.t_dtw >= 0 ? tk.t_dtw / 100 : null;
      const startsWord = /^\s/.test(text) || out.length === 0;
      if (startsWord) out.push({ text: text.trim(), start: from, end: to, dtw });
      else { const w = out[out.length - 1]; w.text += text.trim(); w.end = Math.max(w.end, to); }
    }
  }
  return out.filter((w) => norm(w.text).length > 0);
}
let heard = null;
const wordsFile = opt('--words', null);
try {
  if (wordsFile) heard = JSON.parse(readFileSync(wordsFile, 'utf8'));
  else if (existsSync(P('transcript.json'))) {
    const j = JSON.parse(readFileSync(P('transcript.json'), 'utf8'));
    heard = Array.isArray(j) ? j : Array.isArray(j.words) ? j.words : fromWhisperFull(j);
  }
} catch (e) { fail('No pude leer la transcripción: ' + e.message); }
if (!heard || heard.length === 0) fail('No hay transcripción disponible.');
// Si hay tiempos DTW (más precisos), se usan como inicio de palabra.
for (const w of heard) if (w.dtw != null && Math.abs(w.dtw - w.start) < 0.6) w.start = w.dtw;
log(`Whisper: ${heard.length} palabras reconocidas`);

// ---------- alineación (programación dinámica con uniones 1:2 y 2:1) ----------
function lev(a, b) {
  const m = a.length, n = b.length; if (!m) return n; if (!n) return m;
  let prev = Array.from({ length: n + 1 }, (_, i) => i);
  for (let i = 1; i <= m; i++) {
    const cur = [i];
    for (let j = 1; j <= n; j++) cur[j] = Math.min(prev[j] + 1, cur[j - 1] + 1, prev[j - 1] + (a[i - 1] === b[j - 1] ? 0 : 1));
    prev = cur;
  }
  return prev[n];
}
const sim = (a, b) => (a.length || b.length ? 1 - lev(a, b) / Math.max(a.length, b.length) : 0);
const S = scriptWords.map(norm), H = heard.map((w) => norm(w.text));
const n = S.length, m = H.length, GAP = -0.7;
const score = (s) => (s >= 0.5 ? 2 * s : s - 1.2);
const D = Array.from({ length: n + 1 }, () => new Float64Array(m + 1).fill(-1e9));
const B = Array.from({ length: n + 1 }, () => new Array(m + 1));
D[0][0] = 0;
for (let i = 0; i <= n; i++) for (let j = 0; j <= m; j++) {
  const here = D[i][j]; if (here <= -1e9) continue;
  const tryset = (ii, jj, v, mv) => { if (ii <= n && jj <= m && v > D[ii][jj]) { D[ii][jj] = v; B[ii][jj] = mv; } };
  if (i < n && j < m) tryset(i + 1, j + 1, here + score(sim(S[i], H[j])), [1, 1]);
  if (i < n && j + 1 < m) tryset(i + 1, j + 2, here + score(sim(S[i], H[j] + H[j + 1])) - 0.2, [1, 2]);
  if (i + 1 < n && j < m) tryset(i + 2, j + 1, here + score(sim(S[i] + S[i + 1], H[j])) - 0.2, [2, 1]);
  tryset(i + 1, j, here + GAP, [1, 0]);
  tryset(i, j + 1, here + GAP, [0, 1]);
}
const T = scriptWords.map((text, i) => ({ i, text, start: null, end: null, matched: false }));
let i = n, j = m, matched = 0;
while (i > 0 || j > 0) {
  const mv = B[i][j]; if (!mv) break;
  const [di, dj] = mv;
  if (di > 0 && dj > 0) {
    const hs = heard.slice(j - dj, j);
    const st = hs[0].start, en = hs[hs.length - 1].end;
    if (di === 1) Object.assign(T[i - 1], { start: st, end: en, matched: true });
    else { // dos palabras del guion en una reconocida: repartir por longitud
      const a = T[i - 2], b = T[i - 1], r = a.text.length / (a.text.length + b.text.length);
      const mid = st + (en - st) * r;
      Object.assign(a, { start: st, end: mid, matched: true }); Object.assign(b, { start: mid, end: en, matched: true });
    }
    matched += di;
  }
  i -= di; j -= dj;
}
const ratio = matched / n;
log(`Palabras del guion alineadas con el audio: ${matched}/${n} (${(ratio * 100).toFixed(1)} %)`);
if (ratio < 0.6) fail('Coincidencia demasiado baja; ¿el script.txt corresponde a este audio?');

// Interpolar las palabras sin coincidencia según su longitud
for (let k = 0; k < n; k++) {
  if (T[k].matched) continue;
  let a = k; while (a < n && !T[a].matched) a++;
  const t0 = k > 0 ? T[k - 1].end : (heard[0]?.start ?? 0);
  const t1 = a < n ? T[a].start : heard[heard.length - 1].end;
  const run = T.slice(k, a), tot = run.reduce((s, w) => s + w.text.length, 0) || 1;
  let acc = t0;
  for (const w of run) { const d = (t1 - t0) * (w.text.length / tot); w.start = acc; w.end = acc + d; acc += d; }
  log(`  Interpoladas: ${run.map((w) => w.text).join(' ')}`);
  k = a - 1;
}

// ---------- ajuste a las pausas reales ----------
let silences = [];
try {
  const r = execFileSync('sh', ['-c', `ffmpeg -hide_banner -nostats -i "${P('voice.mp3')}" -af silencedetect=n=-32dB:d=0.09 -f null - 2>&1`], { encoding: 'utf8' });
  let s = null;
  for (const line of r.split('\n')) {
    const a = /silence_start: ([\d.]+)/.exec(line); if (a) s = +a[1];
    const b = /silence_end: ([\d.]+)/.exec(line); if (b && s != null) { silences.push([s, +b[1]]); s = null; }
  }
} catch (e) { log('AVISO: no pude detectar pausas: ' + e.message); }
let snapped = 0;
for (let k = 0; k < n - 1; k++) {
  const a = T[k], b = T[k + 1];
  const lo = a.end - 0.15, hi = b.start + 0.15;
  const cand = silences.filter(([s, e]) => (e - s) >= 0.1 && (s + e) / 2 > lo && (s + e) / 2 < hi && s > a.start + 0.05 && e < b.end - 0.03);
  if (!cand.length) continue;
  const [s, e] = cand.sort((x, y) => (y[1] - y[0]) - (x[1] - x[0]))[0];
  a.end = s; b.start = e; snapped++;
}
if (silences.length && T[0].start < silences[0][1] && silences[0][0] <= 0.01) T[0].start = Math.max(T[0].start, silences[0][1]);
for (let k = 0; k < n; k++) { // monotonía y duración mínima
  if (k > 0 && T[k].start < T[k - 1].end) T[k].start = T[k - 1].end;
  if (T[k].end < T[k].start + 0.06) T[k].end = T[k].start + 0.06;
}
log(`Límites ajustados a pausas reales: ${snapped}`);

// ---------- duración real ----------
let voiceDur = null;
try { voiceDur = parseFloat(execFileSync('ffprobe', ['-v', 'error', '-show_entries', 'format=duration', '-of', 'csv=p=0', P('voice.mp3')], { encoding: 'utf8' })); } catch {}
if (!voiceDur) fail('No pude medir voice.mp3 con ffprobe');
log(`Duración de voice.mp3: ${voiceDur.toFixed(3)} s`);

// ---------- escribir en index.html ----------
let html = readFileSync(P('index.html'), 'utf8');
const r3 = (x) => Math.round(x * 1000) / 1000;
const caps = T.map((w) => ({ i: w.i, text: w.text, start: r3(w.start), end: r3(w.end), src: w.matched ? 'audio' : 'interp' }));
html = html.replace(/(<script id="captions-data" type="application\/json">)[\s\S]*?(<\/script>)/, `$1${JSON.stringify(caps)}$2`);

const tailM = /data-tail="([\d.]+)"/.exec(html); const tail = tailM ? +tailM[1] : 0.6;
const total = Math.round((voiceDur + tail) * 30) / 30;
html = html.replace(/(<div id="main"[^>]*?data-duration=")[\d.]+"/, `$1${total.toFixed(6)}"`);
html = html.replace(/(<audio id="voice"[^>]*?data-duration=")[\d.]+"/, `$1${voiceDur.toFixed(6)}"`);

// Efectos sonoros anclados a palabras
const cuesM = /<script id="sfx-cues" type="application\/json">([\s\S]*?)<\/script>/.exec(html);
if (cuesM) {
  const cues = JSON.parse(cuesM[1]);
  const wavDur = (f) => { try { return parseFloat(execFileSync('ffprobe', ['-v', 'error', '-show_entries', 'format=duration', '-of', 'csv=p=0', P(f)], { encoding: 'utf8' })); } catch { return 2; } };
  const tags = cues.map((c, k) => {
    let at = c.time ?? 0;
    if (c.word != null) { const w = T[c.word]; at = (c.edge === 'end' ? w.end : w.start); }
    at = Math.max(0, r3(at + (c.offset ?? 0)));
    const dur = r3(Math.min(wavDur(c.src), total - at));
    return `<audio id="${c.id}" src="${c.src}" data-start="${at}" data-duration="${dur}" data-volume="${c.volume ?? 0.5}" data-track-index="${2 + k}"></audio>`;
  });
  html = html.replace(/<!--SFX:BEGIN-->[\s\S]*?<!--SFX:END-->/, `<!--SFX:BEGIN-->\n${tags.join('\n')}\n<!--SFX:END-->`);
  log(`Efectos sonoros colocados: ${tags.length}`);
}
writeFileSync(P('index.html'), html);
log('Tiempos por palabra:');
for (const w of caps) log(`  ${w.start.toFixed(3)}–${w.end.toFixed(3)}  ${w.text}${w.src === 'interp' ? '  (interpolada)' : ''}`);
writeFileSync(P('sync-report.txt'), report.join('\n') + '\n');
