window.WORDS=[];
